// Termm-Fall 2024

#ifndef LUA_HPP
#define LUA_HPP

#ifdef __cplusplus
extern "C" {
#endif

#include <lua-5.4.6/src/lua.h>
#include <lua-5.4.6/src/lualib.h>
#include <lua-5.4.6/src/lauxlib.h>
  
#ifdef __cplusplus
}
#endif

#endif
