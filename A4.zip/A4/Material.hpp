// Termm--Fall 2024

#pragma once

class Material {
public:
  virtual ~Material();

protected:
  Material();
};
