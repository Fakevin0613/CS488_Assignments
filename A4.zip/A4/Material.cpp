// Termm--Fall 2024

#include "Material.hpp"

Material::Material()
{}

Material::~Material()
{}
