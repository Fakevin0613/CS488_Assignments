# A0 Instruction

## To get started:
```
premake4 gmake
make
./A0
```

## Assumption
Assume all the codes outside of `guiLogic` in `A0.cpp` are bug free

## Manual
The program is tested and run on gl42.student.cs

